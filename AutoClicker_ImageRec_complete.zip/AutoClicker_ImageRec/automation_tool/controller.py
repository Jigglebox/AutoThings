from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from .automation_engine import AutomationEngine
from .config_loader import AppConfig, ConfigLoader
from .hotkeys import HotkeyListener

LOGGER = logging.getLogger(__name__)


class AutomationController:
    def __init__(self, config_path: Path):
        self._config_path = config_path
        self._config_loader = ConfigLoader(config_path)
        self._engine: Optional[AutomationEngine] = None
        self._hotkey: Optional[HotkeyListener] = None
        self._config: Optional[AppConfig] = None
        self.reload_config()

    @property
    def engine(self) -> AutomationEngine:
        if not self._engine:
            raise RuntimeError("Automation engine not initialized")
        return self._engine

    @property
    def config(self) -> AppConfig:
        if not self._config:
            raise RuntimeError("Config not loaded")
        return self._config

    def start(self) -> None:
        self.engine.start()

    def stop(self) -> None:
        if self._engine:
            self._engine.stop()

    def shutdown(self) -> None:
        if self._hotkey:
            self._hotkey.stop()
        if self._engine:
            self._engine.shutdown()

    def toggle_pause(self) -> bool:
        return self.engine.toggle_pause()

    def reload_config(self) -> None:
        LOGGER.info("Loading configuration from %s", self._config_path)
        config = self._config_loader.load()
        if self._engine:
            self._engine.shutdown()
        if self._hotkey:
            self._hotkey.stop()
        self._config = config
        self._engine = AutomationEngine(config)
        self._hotkey = HotkeyListener(config.hotkeys.pause_resume, self._on_hotkey)
        self._hotkey.start()

    def _on_hotkey(self) -> None:
        paused = self.engine.toggle_pause()
        LOGGER.info("Hotkey toggled pause; paused=%s", paused)
