# AutoClicker_ImageRec - Project Map

## 1. PROJECT OVERVIEW

* **Project Name:** AutoClicker_ImageRec
* **Tech Stack:** Python 3.9+, OpenCV (cv2), mss, numpy, pyautogui, pywin32 (optional), Pillow (PIL), tkinter (ttk), keyboard (optional), pynput (optional), PyYAML (optional)
* **Purpose:** Automate trade interactions in a game or application using image detection (red gem, template matching) and simulated clicks. Supports both GUI and headless modes.
* **Entry Point:** AutoClicker_ImageRec/Auto.py (loads config.json (or .yaml))
* **Run Command:** `python Auto.py`
* **Last Updated:** October 7, 2025

## 2. APPLICATION STRUCTURE

### Entrypoint Files

#### AutoClicker_ImageRec/Auto.py
* **Language:** Python
* **Lines of Code:** 76
* **Functions:** 4 function(s)

### Module Files

#### AutoClicker_ImageRec/automation_tool/automation_engine.py
* **Language:** Python
* **Lines of Code:** 140
* **Exports:** AutomationEngine (class)
* **Functions:** 13 function(s)

#### AutoClicker_ImageRec/automation_tool/clicker.py
* **Language:** Python
* **Lines of Code:** 61
* **Exports:** ClickExecutor (class)
* **Functions:** 3 function(s)

#### AutoClicker_ImageRec/automation_tool/config_loader.py
* **Language:** Python
* **Lines of Code:** 204
* **Exports:** Point (class), Region (class), HSVRange (class), TemplateConfig (class), TradeConfig (class), TimingConfig (class), ClickConfig (class), HotkeyConfig (class), AppConfig (class), ConfigLoader (class)
* **Functions:** 7 function(s)

#### AutoClicker_ImageRec/automation_tool/controller.py
* **Language:** Python
* **Lines of Code:** 73
* **Exports:** AutomationController (class)
* **Functions:** 6 function(s)

#### AutoClicker_ImageRec/automation_tool/detection.py
* **Language:** Python
* **Lines of Code:** 194
* **Exports:** TradeStatus (class), ScreenGrabber (class), ColorDetector (class), TemplateMatcher (class), DetectionManager (class)
* **Functions:** 10 function(s)

#### AutoClicker_ImageRec/automation_tool/gui.py
* **Language:** Python
* **Lines of Code:** 149
* **Exports:** AutomationGUI (class)
* **Functions:** 9 function(s)

#### AutoClicker_ImageRec/automation_tool/hotkeys.py
* **Language:** Python
* **Lines of Code:** 87
* **Exports:** HotkeyListener (class)
* **Functions:** 6 function(s)

#### AutoClicker_ImageRec/automation_tool/__init__.py
* **Language:** Python
* **Lines of Code:** 1

### Configuration Files

#### AutoClicker_ImageRec/config.json
* **Language:** JSON
* **Lines of Code:** 65

### Documentation Files

#### AutoClicker_ImageRec/README.md
* **Language:** Markdown
* **Lines of Code:** 37

## 3. KEY FUNCTIONALITIES

### 3.1 START GUI MODE

**Execution Flow:**

python Auto.py
main() [Auto.py:35]
  → parse_args() [Auto.py:36]
  → configure_logging() [Auto.py:37]
  → AutomationController(config_path) [Auto.py:40]
    → __init__() [controller.py:15]
      → reload_config() [controller.py:21]
        → _config_loader.load() [controller.py:51, config_loader.py:123]
        → AutomationEngine(config) [controller.py:58, automation_engine.py:17]
          → DetectionManager(config) [automation_engine.py:19, detection.py:136]
          → ClickExecutor(config.clicks) [automation_engine.py:20, clicker.py:23]
        → HotkeyListener(...) [controller.py:59, hotkeys.py:23]
          → start() [hotkeys.py:28]
            → _run() [hotkeys.py:42] (starts keyboard/pynput listener thread)
  → AutomationGUI(controller) [Auto.py:52]
    → __init__() [gui.py:18]
      → _build_layout() [gui.py:31] (sets up tkinter widgets and callbacks)
      → _schedule_update() [gui.py:109] (starts periodic status updates)
  → gui.run() [Auto.py:53]
    → self._root.mainloop() [gui.py:NA]

### 3.2 START HEADLESS MODE

**Execution Flow:**

python Auto.py --no-gui
main() [Auto.py:35]
  → parse_args() [Auto.py:36]
  → configure_logging() [Auto.py:37]
  → AutomationController(config_path) [Auto.py:40] (same as GUI mode for controller init)
  → controller.start() [Auto.py:59]
    → self.engine.start() [controller.py:33, automation_engine.py:34]
      → _run_loop() [automation_engine.py:77] (starts automation logic thread)
  → while True: time.sleep(1) [Auto.py:63] (main thread idles)
  → KeyboardInterrupt (user presses Ctrl+C)
  → controller.shutdown() [Auto.py:69] (calls engine.shutdown() and hotkey.stop())

### 3.3 PERFORM TRADE CLICK

**Execution Flow:**

AutomationEngine._run_loop() [automation_engine.py:77]
  → _detection.evaluate_all() [automation_engine.py:83, detection.py:165]
    → evaluate_trade(trade) [detection.py:167]
      → _grabber.grab(trade.region) [detection.py:143, ScreenGrabber:grab()]
      → _color_detector.red_ratio(frame) [detection.py:145, ColorDetector:red_ratio()]
      → _template_matcher.match(frame, trade.start_template) [detection.py:151, TemplateMatcher:match()]
  → _handle_trades(statuses) [automation_engine.py:85]
    → if status.has_red_gem and start_active:
      → _click(trade.start_button) [automation_engine.py:100]
        → self._clicker.click(point) [automation_engine.py:110, clicker.py:34]
          → _win32_click(point) or _pyautogui_click(point) [clicker.py:35/37]
          → time.sleep(post_click_delay) [automation_engine.py:102]

### 3.4 HOTKEY TOGGLE PAUSE

**Execution Flow:**

User presses configured hotkey (e.g., F9)
HotkeyListener._run() detects keypress
  → HotkeyListener._safe_callback() [hotkeys.py:44 or 63]
    → self._callback() (which is controller._on_hotkey) [hotkeys.py:79]
      → controller._on_hotkey() [controller.py:64]
        → self.engine.toggle_pause() [controller.py:65, automation_engine.py:57]
          → AutomationEngine.pause() or AutomationEngine.resume() [automation_engine.py:58/61]
            → self._pause_event.clear() or self._pause_event.set() (pauses/resumes the _run_loop in AutomationEngine)

## 4. FILE DEPENDENCIES

### AutoClicker_ImageRec/Auto.py

* Imports `argparse, logging, RotatingFileHandler, signal, sys, time, Path` from `builtin` (lines 3-10)
* Imports `AutomationController` from `automation_tool.controller` (lines 12)
* Imports `AutomationGUI` from `automation_tool.gui` (lines 13)

### AutoClicker_ImageRec/automation_tool/automation_engine.py

* Imports `logging, threading, time, List, Optional` from `builtin` (lines 3-6)
* Imports `ClickExecutor` from `.clicker` (lines 8)
* Imports `AppConfig, Point` from `.config_loader` (lines 9)
* Imports `DetectionManager, TradeStatus` from `.detection` (lines 10)

### AutoClicker_ImageRec/automation_tool/clicker.py

* Imports `logging, time, Optional` from `builtin` (lines 3-5)
* Imports `pyautogui` from `pyautogui` (lines 8)
* Imports `win32api, win32con` from `win32api` (lines 13)
* Imports `ClickConfig, Point` from `.config_loader` (lines 19)

### AutoClicker_ImageRec/automation_tool/config_loader.py

* Imports `json, logging, dataclass, field, Path, Dict, List, Optional, Sequence, Tuple` from `builtin` (lines 3-7)
* Imports `yaml` from `yaml` (lines 10)

### AutoClicker_ImageRec/automation_tool/controller.py

* Imports `logging, Path, Optional` from `builtin` (lines 3-5)
* Imports `AutomationEngine` from `.automation_engine` (lines 7)
* Imports `AppConfig, ConfigLoader` from `.config_loader` (lines 8)
* Imports `HotkeyListener` from `.hotkeys` (lines 9)

### AutoClicker_ImageRec/automation_tool/detection.py

* Imports `logging, dataclass, Path, Lock, Dict, List, Optional, Tuple` from `builtin` (lines 3-9)
* Imports `cv2` from `cv2` (lines 11)
* Imports `mss` from `mss` (lines 12)
* Imports `numpy` from `numpy` (lines 13)
* Imports `AppConfig, HSVRange, Region, TemplateConfig, TradeConfig` from `.config_loader` (lines 15)

### AutoClicker_ImageRec/automation_tool/gui.py

* Imports `logging, tkinter, Path, Optional` from `builtin` (lines 3-6)
* Imports `cv2` from `cv2` (lines 8)
* Imports `Image, ImageTk` from `PIL` (lines 9)
* Imports `ttk` from `tkinter` (lines 10)
* Imports `AutomationController` from `.controller` (lines 12)

### AutoClicker_ImageRec/automation_tool/hotkeys.py

* Imports `logging, threading, time, Callable, Optional` from `builtin` (lines 3-6)
* Imports `keyboard` from `keyboard` (lines 9)
* Imports `pynput_keyboard` from `pynput` (lines 14)

## 5. FUNCTION CALL GRAPH

### AutoClicker_ImageRec/Auto.py

**Internal Function Calls:**

* `handle_shutdown()` → `getLogger()` (line 43)
* `main()` → `parse_args()` (line 36)
* `main()` → `configure_logging()` (line 37)
* `main()` → `handle_shutdown()` (line 42)
* `main()` → `getLogger()` (line 56)
* `main()` → `getLogger()` (line 61)

**External Function Calls:**

* `main()` calls `automation_tool/controller.py:AutomationController()` (line 40)
* `handle_shutdown()` calls `automation_tool/controller.py:shutdown()` (line 44)
* `main()` calls `automation_tool/gui.py:AutomationGUI()` (line 52)
* `main()` calls `automation_tool/gui.py:run()` (line 53)
* `main()` calls `automation_tool/controller.py:start()` (line 59)
* `main()` calls `automation_tool/controller.py:shutdown()` (line 69)

### AutoClicker_ImageRec/automation_tool/automation_engine.py

**Internal Function Calls:**

* `start()` → `_run_loop()` (line 39)
* `toggle_pause()` → `pause()` (line 58)
* `toggle_pause()` → `resume()` (line 61)
* `_run_loop()` → `_update_statuses()` (line 84)
* `_run_loop()` → `_handle_trades()` (line 85)
* `_run_loop()` → `_handle_collect()` (line 86)
* `_run_loop()` → `_handle_refresh()` (line 87)
* `_handle_trades()` → `_click()` (line 100)
* `_handle_collect()` → `_click()` (line 118)

**External Function Calls:**

* `__init__()` calls `./clicker.py:ClickExecutor()` (line 20)
* `__init__()` calls `./detection.py:DetectionManager()` (line 19)
* `_run_loop()` calls `./detection.py:evaluate_all()` (line 83)
* `_click()` calls `./clicker.py:click()` (line 110)

### AutoClicker_ImageRec/automation_tool/clicker.py

**Internal Function Calls:**

* `click()` → `_win32_click()` (line 35)
* `click()` → `_pyautogui_click()` (line 37)

### AutoClicker_ImageRec/automation_tool/config_loader.py

**Internal Function Calls:**

* `load()` → `_read_raw()` (line 126)
* `load()` → `_parse()` (line 127)
* `_parse()` → `from_mapping()` (line 145)
* `_parse()` → `from_mapping()` (line 156)
* `_parse()` → `from_mapping()` (line 157)

### AutoClicker_ImageRec/automation_tool/controller.py

**Internal Function Calls:**

* `__init__()` → `reload_config()` (line 21)
* `start()` → `engine()` (line 33)
* `toggle_pause()` → `engine()` (line 47)
* `reload_config()` → `_on_hotkey()` (line 61)
* `_on_hotkey()` → `engine()` (line 65)

**External Function Calls:**

* `__init__()` calls `./config_loader.py:ConfigLoader()` (line 17)
* `start()` calls `./automation_engine.py:start()` (line 33)
* `stop()` calls `./automation_engine.py:stop()` (line 37)
* `shutdown()` calls `./hotkeys.py:stop()` (line 42)
* `shutdown()` calls `./automation_engine.py:shutdown()` (line 44)
* `reload_config()` calls `./config_loader.py:load()` (line 51)
* `reload_config()` calls `./automation_engine.py:shutdown()` (line 53)
* `reload_config()` calls `./hotkeys.py:stop()` (line 55)
* `reload_config()` calls `./automation_engine.py:AutomationEngine()` (line 58)
* `reload_config()` calls `./hotkeys.py:HotkeyListener()` (line 59)
* `reload_config()` calls `./hotkeys.py:start()` (line 60)

### AutoClicker_ImageRec/automation_tool/detection.py

**Internal Function Calls:**

* `grab()` → `_bounded_region()` (line 37)
* `has_red()` → `red_ratio()` (line 74)
* `match()` → `_load_template()` (line 106)
* `evaluate_trade()` → `grab()` (line 143)
* `evaluate_trade()` → `red_ratio()` (line 145)
* `evaluate_trade()` → `is_configured()` (line 150)
* `evaluate_trade()` → `match()` (line 151)
* `evaluate_all()` → `evaluate_trade()` (line 167)

**External Function Calls:**

* `grab_monitor()` calls `./config_loader.py:to_monitor()` (line 45)

### AutoClicker_ImageRec/automation_tool/gui.py

**Internal Function Calls:**

* `__init__()` → `_build_layout()` (line 29)
* `__init__()` → `_schedule_update()` (line 30)
* `_build_layout()` → `_on_start()` (line 34)
* `_build_layout()` → `_on_stop()` (line 37)
* `_build_layout()` → `_on_pause()` (line 40)
* `_build_layout()` → `_on_reload()` (line 43)
* `_schedule_update()` → `_update_status()` (line 110)
* `_schedule_update()` → `_schedule_update()` (line 111)
* `_update_status()` → `_bool_to_text()` (line 126)
* `_update_status()` → `_bool_to_text()` (line 127)

**External Function Calls:**

* `_on_close()` calls `./controller.py:shutdown()` (line 24)
* `_on_start()` calls `./controller.py:start()` (line 87)
* `_on_stop()` calls `./controller.py:stop()` (line 92)
* `_on_pause()` calls `./controller.py:toggle_pause()` (line 97)
* `_on_reload()` calls `./controller.py:reload_config()` (line 106)
* `_update_status()` calls `./automation_engine.py:statuses()` (line 115)
* `_update_status()` calls `./automation_engine.py:last_frames()` (line 131)

### AutoClicker_ImageRec/automation_tool/hotkeys.py

**Internal Function Calls:**

* `stop()` → `_detach()` (line 39)
* `start()` → `_run()` (line 32)
* `_run()` → `_safe_callback()` (line 44)
* `_run()` → `_safe_callback()` (line 63)

## 6. DATA STRUCTURES

### Point

* **x:** int
* **y:** int

### Region

* **left:** int
* **top:** int
* **width:** int
* **height:** int

### HSVRange

* **lower:** Tuple[int, int, int]
* **upper:** Tuple[int, int, int]

### TemplateConfig

* **name:** str
* **path:** Path
* **threshold:** float

### TradeConfig

* **name:** str
* **region:** Region
* **start_button:** Point
* **start_template:** Optional[str]
* **start_gray_template:** Optional[str]
* **red_ratio_threshold:** float

### TimingConfig

* **cycle_delay:** float
* **collect_interval:** float
* **refresh_interval:** float
* **post_click_delay:** float

### ClickConfig

* **use_win32:** bool
* **win32_press_duration:** int
* **move_cursor_back:** bool

### HotkeyConfig

* **pause_resume:** str

### AppConfig

* **monitor:** Region
* **trades:** List[TradeConfig]
* **collect_button:** Point
* **refresh_button:** Point
* **hsv_ranges:** List[HSVRange]
* **templates:** Dict[str, TemplateConfig]
* **timing:** TimingConfig
* **clicks:** ClickConfig
* **hotkeys:** HotkeyConfig
* **cycle_delay:** float

### TradeStatus

* **name:** str
* **red_ratio:** float
* **has_red_gem:** bool
* **start_active:** Optional[bool]
* **start_disabled:** Optional[bool]
* **template_score:** Optional[float]

## 7. STATE MANAGEMENT

### Module-Level State

#### AutoClicker_ImageRec/Auto.py:LOG_FILE
* **Type:** Path
* **Line:** 15
* **Initial Value:** Path(__file__).with_name("automation.log")

#### AutoClicker_ImageRec/automation_tool/automation_engine.py:LOGGER
* **Type:** logging.Logger
* **Line:** 12
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/clicker.py:pyautogui
* **Type:** ModuleType | None
* **Line:** 8
* **Initial Value:** None

#### AutoClicker_ImageRec/automation_tool/clicker.py:win32api
* **Type:** ModuleType | None
* **Line:** 13
* **Initial Value:** None

#### AutoClicker_ImageRec/automation_tool/clicker.py:win32con
* **Type:** ModuleType | None
* **Line:** 14
* **Initial Value:** None

#### AutoClicker_ImageRec/automation_tool/clicker.py:LOGGER
* **Type:** logging.Logger
* **Line:** 20
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/config_loader.py:yaml
* **Type:** ModuleType | None
* **Line:** 10
* **Initial Value:** None

#### AutoClicker_ImageRec/automation_tool/config_loader.py:LOGGER
* **Type:** logging.Logger
* **Line:** 13
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/controller.py:LOGGER
* **Type:** logging.Logger
* **Line:** 10
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/detection.py:LOGGER
* **Type:** logging.Logger
* **Line:** 17
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/gui.py:LOGGER
* **Type:** logging.Logger
* **Line:** 13
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/hotkeys.py:LOGGER
* **Type:** logging.Logger
* **Line:** 7
* **Initial Value:** logging.getLogger(__name__)

#### AutoClicker_ImageRec/automation_tool/hotkeys.py:keyboard
* **Type:** ModuleType | None
* **Line:** 9
* **Initial Value:** None

#### AutoClicker_ImageRec/automation_tool/hotkeys.py:pynput_keyboard
* **Type:** ModuleType | None
* **Line:** 14
* **Initial Value:** None

## 8. EVENT HANDLERS

* **signal.SIGINT** → `handle_shutdown()` (AutoClicker_ImageRec/Auto.py:49)
* **signal.SIGTERM** → `handle_shutdown()` (AutoClicker_ImageRec/Auto.py:51)
* **keyboard.hotkey press** → `_safe_callback()` (AutoClicker_ImageRec/automation_tool/hotkeys.py:44)
* **pynput_keyboard.key press** → `on_press()` (AutoClicker_ImageRec/automation_tool/hotkeys.py:57)
* **self._root.WM_DELETE_WINDOW** → `_on_close()` (AutoClicker_ImageRec/automation_tool/gui.py:23)
* **start_button.click** → `_on_start()` (AutoClicker_ImageRec/automation_tool/gui.py:34)
* **stop_button.click** → `_on_stop()` (AutoClicker_ImageRec/automation_tool/gui.py:37)
* **pause_button.click** → `_on_pause()` (AutoClicker_ImageRec/automation_tool/gui.py:40)
* **reload_button.click** → `_on_reload()` (AutoClicker_ImageRec/automation_tool/gui.py:43)
* **self._root.after (1000ms)** → `_schedule_update()` (AutoClicker_ImageRec/automation_tool/gui.py:111)

## 9. DEPENDENCY GRAPH

* **AutoClicker_ImageRec/Auto.py** depends on: AutoClicker_ImageRec/automation_tool/controller.py, AutoClicker_ImageRec/automation_tool/gui.py, AutoClicker_ImageRec/config.json
* **AutoClicker_ImageRec/automation_tool/automation_engine.py** depends on: AutoClicker_ImageRec/automation_tool/clicker.py, AutoClicker_ImageRec/automation_tool/config_loader.py, AutoClicker_ImageRec/automation_tool/detection.py
* **AutoClicker_ImageRec/automation_tool/clicker.py** depends on: AutoClicker_ImageRec/automation_tool/config_loader.py
* **AutoClicker_ImageRec/automation_tool/config_loader.py** has no dependencies
* **AutoClicker_ImageRec/automation_tool/controller.py** depends on: AutoClicker_ImageRec/automation_tool/automation_engine.py, AutoClicker_ImageRec/automation_tool/config_loader.py, AutoClicker_ImageRec/automation_tool/hotkeys.py
* **AutoClicker_ImageRec/automation_tool/detection.py** depends on: AutoClicker_ImageRec/automation_tool/config_loader.py
* **AutoClicker_ImageRec/automation_tool/gui.py** depends on: AutoClicker_ImageRec/automation_tool/controller.py
* **AutoClicker_ImageRec/automation_tool/hotkeys.py** has no dependencies
* **AutoClicker_ImageRec/automation_tool/__init__.py** has no dependencies
* **AutoClicker_ImageRec/config.json** has no dependencies
* **AutoClicker_ImageRec/README.md** has no dependencies

**Circular Dependencies:** none

---

*Generated by Vyber*